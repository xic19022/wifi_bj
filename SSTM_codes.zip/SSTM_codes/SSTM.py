#!/usr/bin/python
# -*- coding: UTF-8 -*-

import csv
import datetime
from openpyxl import load_workbook

# open an existing file of weekend dates during the study period
daytypefilepath = './file/weekend_date_dict.xlsx'

# open an existing file of time periods in a day
timeperiodfilepath = './file/time_period_dict.xlsx'

# open an existing file of major activity type near each Wi-Fi detector
activitytypefilepath = './file/activity_type_dict.xlsx'

#open an existing csv file of raw Wi-Fi data
inputfilepath = './file/Wifi.csv'

# read the file of weekend dates during the study period
def get_daytype():
    wb = load_workbook(daytypefilepath)
    sheet = wb['Sheet1']
    daytype_list = []
    for row in range(1, sheet.max_row + 1):
        daytype_list.append(str(sheet.cell(row, 1).value))
    wb.close()
    return daytype_list

# read the file of  time periods in a day
def get_timeperiod():
    wb = load_workbook(timeperiodfilepath)
    sheet = wb['Sheet1']
    timeperiod_list = {}
    for row in range(2, sheet.max_row + 1):
        timeperiod_list.update({int(sheet.cell(row, 2).value): int(sheet.cell(row, 1).value)})
    wb.close()
    return timeperiod_list

# read the file of major activity type near each Wi-Fi detector
def get_activitytype():
    wb = load_workbook(activitytypefilepath)
    sheet = wb['Sheet1']
    activitytype_list = {}
    for row in range(2, sheet.max_row + 1):
        activitytype_list.update({str(sheet.cell(row, 2).value): sheet.cell(row, 1).value})
    wb.close()
    return activitytype_list

# main program
def main():
    # get starttime
    starttime = datetime.datetime.now()

    # define path of output file
    outfilepath = './file/output_SSTM.csv'

    # get value from the file of weekend dates
    daytype_list = get_daytype()

    # define number of day types (including weekday and weekend)
    daytype_num = 2

    # get value from the file of time periods
    timeperiod_list = get_timeperiod()

    # get number of time periods
    timeperiod_num = max(timeperiod_list.values())

    # get value from the file of major activity type
    activitytype_list = get_activitytype()

    # get number of major activity type
    activitytype_num = max(activitytype_list.values())

    #  select the records of user_MAC from the csv file and store it in the variable of rs
    with open(inputfilepath, 'r') as csvfile:
        reader = csv.DictReader(csvfile)
        column = [line['user_MAC'] for line in reader]
    rs = list(set(column))

    # write the output file as a csv file
    try:
        with open(outfilepath, "w", newline='') as csvfile:
            writer = csv.writer(csvfile)

            # write the names of columns in the output file
            colname = ['id', 'user_MAC']
            for w in range(1, daytype_num + 1):
                for at in range(1, activitytype_num + 1):
                    for tp in range(1, timeperiod_num + 1):
                        colname.append('TP' + str(tp) + '_AT' + str(at) + '_W' + str(w))
            writer.writerow(colname)

            # traverse all user_MAC in the variable rs and calculate the visit frequency in the SSTM
            for pass_num, (user_MAC) in enumerate(rs):
                print('Reading No. %s user_MAC' % str(pass_num))
                row = [str(pass_num + 1), user_MAC]
                try:
                    # get attribute values of the record of a specific user_MAC
                    rs_temp = []
                    with open(inputfilepath, 'r') as csvfile:
                        reader = csv.reader(csvfile)
                        for line in reader:
                            try:
                                if line[1] == user_MAC:
                                    rs_temp.append(line)
                            except:
                                pass
                    data_temp = [0] * (timeperiod_num * activitytype_num * daytype_num)
                    for row_num, (Wifi_detector_ID_str, user_MAC, date_str, ftime_str, ltime_str) in enumerate(rs_temp):
                        try:
                            Wifi_detector_ID = int(Wifi_detector_ID_str)
                            date = datetime.datetime.strptime(date_str, '%Y/%m/%d')
                            ftime = datetime.datetime.strptime(date_str + ' ' + ftime_str, '%Y/%m/%d  %H:%M:%S')
                            ltime = datetime.datetime.strptime(date_str + ' ' + ltime_str, '%Y/%m/%d  %H:%M:%S')
                            for hour in range(timeperiod_list.get(ftime.hour) - 1, timeperiod_list.get(ltime.hour)):
                                if date.strftime('%Y-%m-%d %H:%M:%S') in daytype_list:
                                    index = (activitytype_list.get(str(
                                        Wifi_detector_ID)) - 1) * timeperiod_num + hour + activitytype_num * timeperiod_num
                                    data_temp[index] += 1
                                else:
                                    index = (activitytype_list.get(str(Wifi_detector_ID)) - 1) * timeperiod_num + hour
                                    data_temp[index] += 1
                        except Exception as e:
                            print(e)
                            continue

                    # output the result of visit frequency
                    row.extend(data_temp)
                except Exception as e:
                    print(e)
                finally:
                    writer.writerow(row)
    except Exception as e:
        print(e)
    finally:
        pass

    # get endtime and print run time of the main program
    endtime = datetime.datetime.now()
    print('This program takes' + str((endtime - starttime).seconds) + 's��')


# run the main program
if __name__ == '__main__':
    main()
